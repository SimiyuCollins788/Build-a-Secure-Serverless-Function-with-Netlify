# Create Your First Serverless Function

This is a starter file for a tweet thread from [Chris On Code](https://twitter.com/chrisoncode).

